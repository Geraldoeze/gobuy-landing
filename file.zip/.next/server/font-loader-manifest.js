self.__FONT_LOADER_MANIFEST={
  "pages": {},
  "app": {
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\@next\\font\\google\\target.css?{\"arguments\":[{\"subsets\":[\"latin\"]}],\"import\":\"Inter\",\"path\":\"app\\\\page.tsx\",\"variableName\":\"inter\"}": [
      "static/media/c9a5bc6a7c948fb0.p.woff2"
    ]
  }
}