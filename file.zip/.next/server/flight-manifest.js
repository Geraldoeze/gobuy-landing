self.__RSC_MANIFEST={
  "__ssr_module_mapping__": {
    "(app-client)/./components/Common/ScrollUp.tsx": {
      "": {
        "id": "(sc_client)/./components/Common/ScrollUp.tsx",
        "name": "",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/Common/ScrollUp.tsx",
        "name": "*",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/Common/ScrollUp.tsx",
        "name": "default",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      }
    },
    "(app-client)/./components/Video/index.tsx": {
      "": {
        "id": "(sc_client)/./components/Video/index.tsx",
        "name": "",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./components/Video/index.tsx",
        "name": "*",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/Video/index.tsx",
        "name": "default",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/image.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "*",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "default",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      }
    },
    "(app-client)/./app/layout.tsx": {
      "": {
        "id": "(sc_client)/./app/layout.tsx",
        "name": "",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./app/layout.tsx",
        "name": "*",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./app/layout.tsx",
        "name": "default",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/link.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "*",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/link.js",
        "name": "default",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    }
  },
  "__edge_ssr_module_mapping__": {},
  "__entry_css_files__": {
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\layout": [
      "static/css/app/layout.css"
    ],
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\page": [
      "static/css/_app-client_node_modules_next_font_google_target_css_arguments_subsets_latin_import_Inter_pat-2ed68b.css"
    ]
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\components\\Common\\ScrollUp.tsx": {
    "": {
      "id": "(app-client)/./components/Common/ScrollUp.tsx",
      "name": "",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/Common/ScrollUp.tsx",
      "name": "*",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/Common/ScrollUp.tsx",
      "name": "default",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\components\\Video\\index.tsx": {
    "": {
      "id": "(app-client)/./components/Video/index.tsx",
      "name": "",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./components/Video/index.tsx",
      "name": "*",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./components/Video/index.tsx",
      "name": "default",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\image.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "*",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "default",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\react-modal-video\\css\\modal-video.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\styles\\index.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\layout.tsx": {
    "": {
      "id": "(app-client)/./app/layout.tsx",
      "name": "",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./app/layout.tsx",
      "name": "*",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./app/layout.tsx",
      "name": "default",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\link.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "*",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/link.js",
      "name": "default",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\components\\app-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\@next\\font\\google\\target.css?{\"arguments\":[{\"subsets\":[\"latin\"]}],\"import\":\"Inter\",\"path\":\"app\\\\page.tsx\",\"variableName\":\"inter\"}": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/_app-client_node_modules_next_font_google_target_css_arguments_subsets_latin_import_Inter_pat-2ed68b.css"
      ]
    }
  }
}