self.__RSC_CSS_MANIFEST={
  "__entry_css_mods__": {
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\page": [
      "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\react-modal-video\\css\\modal-video.css",
      "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\styles\\index.css"
    ],
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\about\\page": [
      "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\react-modal-video\\css\\modal-video.css",
      "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\styles\\index.css"
    ]
  },
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\page.tsx": [
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\@next\\font\\google\\target.css?{\"arguments\":[{\"subsets\":[\"latin\"]}],\"import\":\"Inter\",\"path\":\"app\\\\page.tsx\",\"variableName\":\"inter\"}"
  ],
  "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\app\\layout.tsx": [
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\node_modules\\react-modal-video\\css\\modal-video.css",
    "C:\\Users\\HP\\Desktop\\PROJECTS\\AZ\\startup-nextjs-main\\styles\\index.css"
  ]
}